// IDENTIFIERS_USED=leftmotorAsDcMotor,rightmotorAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    leftmotorAsDcMotor.setDirection("REVERSE");
    rightmotorAsDcMotor.setDirection("FORWARD");
    while (linearOpMode.opModeIsActive()) {
      leftmotorAsDcMotor.setDualPower(1, rightmotorAsDcMotor, 1);
      telemetry.update();
    }
  }
}
