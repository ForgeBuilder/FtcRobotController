// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

var leftTarget, rightTarget, speed, leftPos, rightPos;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDirection("REVERSE");
  rightFrontAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    drive(-1050, 1050, 0.5);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function drive(leftTarget, rightTarget, speed) {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftPos = (typeof leftPos == 'number' ? leftPos : 0) + leftTarget;
  rightPos = (typeof rightPos == 'number' ? rightPos : 0) + rightTarget;
  leftBackAsDcMotor.setDualTargetPosition(leftPos, leftFrontAsDcMotor, leftPos);
  rightBackAsDcMotor.setDualTargetPosition(rightPos, rightFrontAsDcMotor, rightPos);
  leftBackAsDcMotor.setDualMode("RUN_TO_POSITION", leftFrontAsDcMotor, "RUN_TO_POSITION");
  rightBackAsDcMotor.setDualMode("RUN_TO_POSITION", rightFrontAsDcMotor, "RUN_TO_POSITION");
  rightBackAsDcMotor.setDualPower(1, rightFrontAsDcMotor, 1);
  leftBackAsDcMotor.setDualPower(1, leftFrontAsDcMotor, 1);
  leftBackAsDcMotor.setDualVelocity(400, leftFrontAsDcMotor, 400);
  rightBackAsDcMotor.setDualVelocity(400, rightFrontAsDcMotor, 400);
  while (leftBackAsDcMotor.isBusy() && leftFrontAsDcMotor.isBusy() && rightBackAsDcMotor.isBusy() && rightFrontAsDcMotor.isBusy() && linearOpMode.opModeIsActive()) {
    linearOpMode.waitForStart();
    linearOpMode.idle();
  }
}
