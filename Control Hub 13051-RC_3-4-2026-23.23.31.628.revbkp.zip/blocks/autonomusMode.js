// IDENTIFIERS_USED=leftmotorAsDcMotor,rightmotorAsDcMotor

var right, left, speed;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  leftmotorAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
}

/**
 * Describe this function...
 */
function Drive(right, left, speed) {
  leftmotorAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightmotorAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftmotorAsDcMotor.setDualTargetPosition(left, rightmotorAsDcMotor, right);
  leftmotorAsDcMotor.setDualMode("RUN_TO_POSITION", rightmotorAsDcMotor, "RUN_TO_POSITION");
  leftmotorAsDcMotor.setDualPower(speed, rightmotorAsDcMotor, speed);
  while (linearOpMode.opModeIsActive() && leftmotorAsDcMotor.isBusy() && rightmotorAsDcMotor.isBusy()) {
    linearOpMode.idle();
  }
}
