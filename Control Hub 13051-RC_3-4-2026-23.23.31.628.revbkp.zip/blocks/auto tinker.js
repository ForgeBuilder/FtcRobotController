// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightFrontAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightBackAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftBackAsDcMotor.setDirection("REVERSE");
  leftFrontAsDcMotor.setDirection("REVERSE");
  rightBackAsDcMotor.setDirection("REVERSE");
  leftBackAsDcMotor.setTargetPosition(0);
  leftFrontAsDcMotor.setTargetPosition(0);
  rightFrontAsDcMotor.setTargetPosition(0);
  rightBackAsDcMotor.setTargetPosition(0);
  leftFrontAsDcMotor.setPower(0.1);
  leftBackAsDcMotor.setPower(0.1);
  rightBackAsDcMotor.setPower(0.1);
  rightFrontAsDcMotor.setPower(0.1);
  rightFrontAsDcMotor.setDualMode("RUN_TO_POSITION", rightBackAsDcMotor, "RUN_TO_POSITION");
  rightBackAsDcMotor.setDualMode("RUN_TO_POSITION", rightFrontAsDcMotor, "RUN_TO_POSITION");
  leftBackAsDcMotor.setDualMode("RUN_TO_POSITION", leftFrontAsDcMotor, "RUN_TO_POSITION");
  leftFrontAsDcMotor.setDualMode("RUN_TO_POSITION", leftBackAsDcMotor, "RUN_TO_POSITION");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    leftFrontAsDcMotor.setTargetPosition(-500);
    leftBackAsDcMotor.setTargetPosition(-500);
    rightBackAsDcMotor.setTargetPosition(-500);
    rightFrontAsDcMotor.setTargetPosition(-500);
    while (linearOpMode.opModeIsActive()) {
      telemetry.addTextData('LeftFront Position', String(leftFrontAsDcMotor.getCurrentPosition()));
      telemetry.addTextData('RightFront Position', String(rightFrontAsDcMotor.getCurrentPosition()));
      telemetry.addTextData('LeftBack Position', String(leftBackAsDcMotor.getCurrentPosition()));
      telemetry.addTextData('RightBack Position', String(rightBackAsDcMotor.getCurrentPosition()));
      telemetry.update();
    }
  }
}
