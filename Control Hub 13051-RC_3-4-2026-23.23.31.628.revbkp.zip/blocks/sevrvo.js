// IDENTIFIERS_USED=gamepad1,left_handAsServo

var ServoPosition, ServoSpeed;

/**
 * This sample OpMode shows how to operate a
 * conventional servo at a smooth, controlled rate.
 */
function runOpMode() {
  ServoPosition = 0.5;
  ServoSpeed = 0.01;
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getB()) {
      ServoPosition = (typeof ServoPosition == 'number' ? ServoPosition : 0) + ServoSpeed;
    }
    if (gamepad1.getX()) {
      ServoPosition = (typeof ServoPosition == 'number' ? ServoPosition : 0) + -ServoSpeed;
    }
    ServoPosition = Math.min(Math.max(ServoPosition, 0), 1);
    left_handAsServo.setPosition(ServoPosition);
    telemetry.addNumericData('Servo', ServoPosition);
    telemetry.update();
    linearOpMode.sleep(20);
  }
}
