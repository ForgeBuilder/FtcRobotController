// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      rightFrontAsDcMotor.setPower(1);
      telemetry.update();
      linearOpMode.sleep(1000);
      rightFrontAsDcMotor.setPower(0);
      telemetry.update();
      linearOpMode.sleep(1000);
      rightBackAsDcMotor.setPower(1);
      telemetry.update();
      linearOpMode.sleep(1000);
      rightBackAsDcMotor.setPower(0);
      telemetry.update();
      linearOpMode.sleep(1000);
      leftFrontAsDcMotor.setPower(1);
      telemetry.update();
      linearOpMode.sleep(1000);
      leftFrontAsDcMotor.setPower(0);
      telemetry.update();
      linearOpMode.sleep(1000);
      leftBackAsDcMotor.setPower(1);
      telemetry.update();
      linearOpMode.sleep(1000);
      leftBackAsDcMotor.setPower(0);
    }
  }
}
