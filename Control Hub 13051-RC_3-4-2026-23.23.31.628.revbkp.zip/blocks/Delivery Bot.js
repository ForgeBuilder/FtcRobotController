// IDENTIFIERS_USED=back_left_motorAsDcMotor,back_right_motorAsDcMotor,colorAsColorSensor,front_left_motorAsDcMotor,front_right_motorAsDcMotor

var CurrentColor;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  back_left_motorAsDcMotor.setDirection("REVERSE");
  front_left_motorAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    telemetry.addNumericData('Blue', 123);
  }
  if (CurrentColor) {
    back_left_motorAsDcMotor.setDualPower(1, back_right_motorAsDcMotor, 1);
    back_left_motorAsDcMotor.setDualPower(1, back_right_motorAsDcMotor, 1);
    front_left_motorAsDcMotor.setDualPower(1, front_right_motorAsDcMotor, 1);
    linearOpMode.sleep(2000);
    back_left_motorAsDcMotor.setDualPower(2.1, back_right_motorAsDcMotor, 1.4);
    colorAsColorSensor.enableLed(false);
  } else {
  }
}
