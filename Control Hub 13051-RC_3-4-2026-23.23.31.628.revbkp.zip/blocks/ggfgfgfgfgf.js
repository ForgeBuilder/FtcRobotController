// IDENTIFIERS_USED=rightBackAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      rightBackAsDcMotor.setPower(1);
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function run_opmode() {
}
