// IDENTIFIERS_USED=gamepad1,lbAsDcMotor,lfAsDcMotor,rbAsDcMotor,rfAsDcMotor,testservoAsServo

var full_speed_, even_slower, strafe, forward2, turn;

/**
 * Describe this function...
 */
function do_something() {
}

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  full_speed_ = false;
  even_slower = false;
  lbAsDcMotor.setZeroPowerBehavior("BRAKE");
  lfAsDcMotor.setZeroPowerBehavior("BRAKE");
  rbAsDcMotor.setZeroPowerBehavior("BRAKE");
  rfAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    rbAsDcMotor.setDirection("REVERSE");
    rfAsDcMotor.setDirection("REVERSE");
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getLeftTrigger() > 0) {
        testservoAsServo.setPosition(testservoAsServo.getPosition() + 0.01);
      }
      if (gamepad1.getRightTrigger() > 0) {
        testservoAsServo.setPosition(testservoAsServo.getPosition() - 0.01);
      }
      if (full_speed_) {
        strafe = gamepad1.getLeftStickX() / 2;
        forward2 = gamepad1.getLeftStickY() / 2;
        turn = gamepad1.getRightStickX() / 2;
      } else if (even_slower) {
        strafe = gamepad1.getLeftStickX() / 5;
        forward2 = gamepad1.getLeftStickY() / 5;
        turn = gamepad1.getRightStickX() / 5;
      } else {
        strafe = gamepad1.getLeftStickX();
        forward2 = gamepad1.getLeftStickY();
        turn = gamepad1.getRightStickX();
      }
      if (gamepad1.getXWasPressed()) {
        full_speed_ = !full_speed_;
        even_slower = false;
      }
      if (gamepad1.getYWasReleased()) {
        even_slower = !even_slower;
        full_speed_ = false;
      }
      lfAsDcMotor.setPower(forward2 - (strafe + turn));
      lbAsDcMotor.setPower(forward2 + (strafe - turn));
      rfAsDcMotor.setPower(forward2 + strafe + turn);
      rbAsDcMotor.setPower(forward2 - (strafe - turn));
      telemetry.update();
    }
  }
}
