// IDENTIFIERS_USED=_1AsCRServo,_2AsCRServo,_3AsCRServo,_4AsCRServo,_5AsCRServo,gamepad1

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getAWasPressed()) {
        _1AsCRServo.setPower(0);
        _2AsCRServo.setPower(0);
        _3AsCRServo.setPower(0);
        _4AsCRServo.setPower(0);
        _5AsCRServo.setPower(0);
      }
      if (gamepad1.getBWasPressed()) {
        _1AsCRServo.setPower(1);
        _2AsCRServo.setPower(1);
        _3AsCRServo.setPower(1);
        _4AsCRServo.setPower(1);
        _5AsCRServo.setPower(1);
      }
      telemetry.update();
    }
  }
}
