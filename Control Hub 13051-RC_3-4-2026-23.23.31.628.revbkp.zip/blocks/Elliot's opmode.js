// IDENTIFIERS_USED=gamepad1,leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

var forward2, Strafe, turn;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  rightBackAsDcMotor.setDirection("REVERSE");
  rightFrontAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
      telemetryAddTextData('goof', 'goof');
      telemetryAddTextData('LB position', leftBackAsDcMotor.getCurrentPosition());
      forward2 = -gamepad1.getLeftStickY();
      Strafe = gamepad1.getLeftStickX();
      turn = gamepad1.getRightStickX();
      leftFrontAsDcMotor.setPower(forward2 + Strafe + turn);
      leftBackAsDcMotor.setPower(forward2 - (Strafe - turn));
      rightFrontAsDcMotor.setPower(forward2 - (Strafe + turn));
      rightBackAsDcMotor.setPower(forward2 + (Strafe - turn));
    }
  }
}
