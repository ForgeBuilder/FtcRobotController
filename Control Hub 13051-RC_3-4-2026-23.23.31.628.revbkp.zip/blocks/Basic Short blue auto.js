// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

var leftpos, rightpos;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    leftBackAsDcMotor.setDualZeroPowerBehavior("BRAKE", leftFrontAsDcMotor, "BRAKE");
    rightBackAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightFrontAsDcMotor, "BRAKE");
    rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    rightpos = 0;
    leftpos = 0;
    while (linearOpMode.opModeIsActive()) {
      while (rightpos < 10000) {
        leftFrontAsDcMotor.setPower(-0.5);
        leftBackAsDcMotor.setPower(-0.5);
        rightBackAsDcMotor.setPower(0.5);
        rightFrontAsDcMotor.setPower(0.5);
        rightpos = rightBackAsDcMotor.getCurrentPosition();
        telemetry.addTextData('position', String(rightBackAsDcMotor.getCurrentPosition()));
        telemetry.update();
      }
      rightFrontAsDcMotor.setPower(0);
      rightBackAsDcMotor.setPower(0);
      leftBackAsDcMotor.setPower(0);
      leftFrontAsDcMotor.setPower(0);
    }
  }
}
