// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    rightFrontAsDcMotor.setPower(0.25);
    rightFrontAsDcMotor.setDirection("FORWARD");
    leftBackAsDcMotor.setPower(0.25);
    leftBackAsDcMotor.setDirection("FORWARD");
    leftFrontAsDcMotor.setPower(0.25);
    leftFrontAsDcMotor.setDirection("FORWARD");
    rightBackAsDcMotor.setPower(0.25);
    rightBackAsDcMotor.setDirection("REVERSE");
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}
