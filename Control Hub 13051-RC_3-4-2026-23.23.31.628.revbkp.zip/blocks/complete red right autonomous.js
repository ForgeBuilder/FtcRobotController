// IDENTIFIERS_USED=dropServoAsServo,leftBackAsDcMotor,leftBeltAsDcMotor,leftDistAsDistanceSensor,leftFrontAsDcMotor,leftLiftAsDcMotor,rightBackAsDcMotor,rightBeltAsDcMotor,rightDistAsDistanceSensor,rightFrontAsDcMotor,rightLiftAsDcMotor

var leftTarget, rightTarget, speed, Right_Target, block_position;

/**
 * Describe this function...
 */
function drive(leftTarget, rightTarget, speed) {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualVelocity(speed, rightFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualVelocity(speed, leftFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualTargetPosition(leftTarget, leftFrontAsDcMotor, leftTarget);
  rightBackAsDcMotor.setDualTargetPosition(rightTarget, rightFrontAsDcMotor, rightTarget);
  rightBackAsDcMotor.setDualMode("RUN_TO_POSITION", rightFrontAsDcMotor, "RUN_TO_POSITION");
  leftBackAsDcMotor.setDualMode("RUN_TO_POSITION", leftFrontAsDcMotor, "RUN_TO_POSITION");
  rightBackAsDcMotor.setDualVelocity(speed, rightFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualVelocity(speed, leftFrontAsDcMotor, speed);
  while (leftBackAsDcMotor.isBusy() && leftFrontAsDcMotor.isBusy() && rightBackAsDcMotor.isBusy() && rightFrontAsDcMotor.isBusy() && linearOpMode.opModeIsActive()) {
    linearOpMode.waitForStart();
    linearOpMode.idle();
  }
}

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDirection("REVERSE");
  rightFrontAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    linearOpMode.sleep(5500);
    drive(1390, 1390, 800);
    leftBackAsDcMotor.setDualPower(0, leftFrontAsDcMotor, 0);
    rightBackAsDcMotor.setDualPower(0, rightFrontAsDcMotor, 0);
    leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    if (leftDistAsDistanceSensor.getDistance("CM") < 20) {
      block_position = 75;
      telemetry.addTextData('Sensor left', String(1));
      telemetry.update();
      drive(-1075, 1075, 800);
      leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
      rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
      Drop_stuff();
      reset_encoders();
      drive(-1475, -1475, 800);
      dropServoAsServo.setPosition(-2);
      reset_encoders();
      rightBeltAsDcMotor.setDualPower(-1, leftBeltAsDcMotor, 1);
      drive(2100, -2100, 800);
      rightBeltAsDcMotor.setDualPower(0, leftBeltAsDcMotor, 0);
    } else if (rightDistAsDistanceSensor.getDistance("CM") < 20) {
      block_position = 53;
      telemetry.addTextData('Sensor right', String(1));
      telemetry.update();
      drive(1075, -1075, 800);
      leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
      rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
      Drop_stuff();
      reset_encoders();
      drive(-30, -30, 800);
      dropServoAsServo.setPosition(-2);
      leftBeltAsDcMotor.setDualPower(1, rightBeltAsDcMotor, -1);
      reset_encoders();
      Strafe_with_(1075, 800);
      reset_encoders();
      rightBeltAsDcMotor.setDualPower(0, leftBeltAsDcMotor, 0);
      drive(1520, 1520, 800);
    } else {
      dropServoAsServo.setPosition(0.3);
      block_position = 66;
      drive(-1200, -1200, 800);
      dropServoAsServo.setPosition(-2);
      reset_encoders();
      rightBeltAsDcMotor.setDualPower(-1, leftBeltAsDcMotor, 1);
      drive(1075, -1075, 800);
      rightBeltAsDcMotor.setDualPower(0, leftBeltAsDcMotor, 0);
      reset_encoders();
      drive(1550, 1550, 800);
    }
    reset_encoders();
    leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
    rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
    rightBackAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", rightFrontAsDcMotor, "RUN_WITHOUT_ENCODER");
    leftBackAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", leftFrontAsDcMotor, "RUN_WITHOUT_ENCODER");
    leftBackAsDcMotor.setDualVelocity(500, leftFrontAsDcMotor, -500);
    rightBackAsDcMotor.setDualVelocity(-500, rightFrontAsDcMotor, 500);
    while (rightDistAsDistanceSensor.getDistance("CM") < block_position) {
    }
    leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
    rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
    rightLiftAsDcMotor.setDirection("REVERSE");
    leftLiftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightLiftAsDcMotor, "STOP_AND_RESET_ENCODER");
    rightLiftAsDcMotor.setDualTargetPosition(1650, leftLiftAsDcMotor, 1650);
    leftLiftAsDcMotor.setDualMode("RUN_TO_POSITION", rightLiftAsDcMotor, "RUN_TO_POSITION");
    rightLiftAsDcMotor.setDualVelocity(500, leftLiftAsDcMotor, 500);
    while (rightLiftAsDcMotor.isBusy()) {
      linearOpMode.idle();
    }
    reset_encoders();
    drive(250, 250, 100);
    linearOpMode.sleep(500);
    dropServoAsServo.setPosition(0.3);
    linearOpMode.sleep(200);
    drive(-250, -250, 50);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
    rightLiftAsDcMotor.setDirection("REVERSE");
  }
}

/**
 * Describe this function...
 */
function Strafe_with_(Right_Target, speed) {
  rightFrontAsDcMotor.setDirection("FORWARD");
  leftBackAsDcMotor.setDirection("REVERSE");
  drive(Right_Target, Right_Target, speed);
  rightFrontAsDcMotor.setDirection("REVERSE");
  leftBackAsDcMotor.setDirection("FORWARD");
}

/**
 * Describe this function...
 */
function Drop_stuff() {
  linearOpMode.sleep(500);
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  drive(150, 150, 400);
  leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
  rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
  dropServoAsServo.setPosition(0.3);
  linearOpMode.sleep(500);
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  drive(-150, -150, 400);
  leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
  rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
}

/**
 * Describe this function...
 */
function reset_encoders() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
}
