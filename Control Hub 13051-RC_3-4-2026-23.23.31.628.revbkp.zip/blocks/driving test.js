// IDENTIFIERS_USED=leftBackAsDcMotor,leftFrontAsDcMotor,rightBackAsDcMotor,rightFrontAsDcMotor

/**
 * Describe this function...
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    leftBackAsDcMotor.setDirection("REVERSE");
    leftBackAsDcMotor.setPower(0.1);
    leftFrontAsDcMotor.setDirection("REVERSE");
    leftFrontAsDcMotor.setPower(0.1);
    rightBackAsDcMotor.setDirection("FORWARD");
    rightBackAsDcMotor.setPower(0.1);
    rightFrontAsDcMotor.setDirection("FORWARD");
    rightFrontAsDcMotor.setPower(0.1);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}
