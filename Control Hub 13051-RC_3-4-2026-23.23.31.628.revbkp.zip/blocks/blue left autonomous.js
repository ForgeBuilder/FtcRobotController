// IDENTIFIERS_USED=dropServoAsServo,leftBackAsDcMotor,leftDistAsDistanceSensor,leftFrontAsDcMotor,rightBackAsDcMotor,rightDistAsDistanceSensor,rightFrontAsDcMotor

var leftTarget, rightTarget, speed;

/**
 * Describe this function...
 */
function drive(leftTarget, rightTarget, speed) {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualVelocity(speed, rightFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualVelocity(speed, leftFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualTargetPosition(leftTarget, leftFrontAsDcMotor, leftTarget);
  rightBackAsDcMotor.setDualTargetPosition(rightTarget, rightFrontAsDcMotor, rightTarget);
  rightBackAsDcMotor.setDualMode("RUN_TO_POSITION", rightFrontAsDcMotor, "RUN_TO_POSITION");
  leftBackAsDcMotor.setDualMode("RUN_TO_POSITION", leftFrontAsDcMotor, "RUN_TO_POSITION");
  rightBackAsDcMotor.setDualVelocity(speed, rightFrontAsDcMotor, speed);
  leftBackAsDcMotor.setDualVelocity(speed, leftFrontAsDcMotor, speed);
  while (leftBackAsDcMotor.isBusy() && leftFrontAsDcMotor.isBusy() && rightBackAsDcMotor.isBusy() && rightFrontAsDcMotor.isBusy() && linearOpMode.opModeIsActive()) {
    linearOpMode.waitForStart();
    linearOpMode.idle();
  }
}

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDirection("REVERSE");
  rightFrontAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    drive(1390, 1390, 400);
    leftBackAsDcMotor.setDualPower(0, leftFrontAsDcMotor, 0);
    rightBackAsDcMotor.setDualPower(0, rightFrontAsDcMotor, 0);
    leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
    if (leftDistAsDistanceSensor.getDistance("CM") < 20) {
      telemetry.addTextData('Sensor left', String(1));
      telemetry.update();
      drive(-1050, 1050, 400);
      leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
      rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
      Drop_stuff();
      reset_encoders();
      drive(-100, -100, 400);
      reset_encoders();
      drive(1050, -1050, 400);
      reset_encoders();
      drive(-1200, -1200, 300);
      reset_encoders();
      drive(-1050, 1050, 300);
      reset_encoders();
      drive(1700, 1700, 300);
    } else if (rightDistAsDistanceSensor.getDistance("CM") < 20) {
      telemetry.addTextData('Sensor right', String(1));
      telemetry.update();
      drive(1050, -1050, 400);
      leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
      rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
      Drop_stuff();
      reset_encoders();
      drive(-70, -70, 400);
      reset_encoders();
      drive(-1050, 1050, 400);
      reset_encoders();
      drive(-1200, -1200, 300);
      reset_encoders();
      drive(-1050, 1050, 300);
      reset_encoders();
      drive(1700, 1700, 300);
    } else {
      dropServoAsServo.setPosition(0.3);
      drive(-1200, -1200, 300);
      drive(-1050, 1050, 300);
      drive(1500, 1500, 300);
    }
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function Drop_stuff() {
  linearOpMode.sleep(500);
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  drive(150, 150, 400);
  leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
  rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
  dropServoAsServo.setPosition(0.3);
  linearOpMode.sleep(500);
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  drive(-150, -150, 400);
  leftBackAsDcMotor.setDualVelocity(0, leftFrontAsDcMotor, 0);
  rightBackAsDcMotor.setDualVelocity(0, rightFrontAsDcMotor, 0);
}

/**
 * Describe this function...
 */
function reset_encoders() {
  leftBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
  rightBackAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightFrontAsDcMotor, "STOP_AND_RESET_ENCODER");
}
